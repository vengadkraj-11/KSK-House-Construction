# KSK House Construction — Project Records update

## Included in this source update

- Added a Project Records screen with Firestore-backed payment ledger, material stock movements, construction progress entries, site diary metadata, expense approval records, and payment reminder records.
- Added owner-only create/update/delete and project-member read rules for each new collection.
- Existing Excel-style worksheets and existing receipt image storage are unchanged.
- New payment records are separate from historic daily-expense worksheet rows; historic entries are not silently migrated or double-counted.

## Important limitations still requiring a separate tested implementation

- Person-wise statement reconciliation/export (especially a genuinely encrypted PDF that opens with a PDF-reader password) is not implemented in this update. Do not describe a normal PDF as encrypted.
- Diary records currently store metadata only; they do not upload photo bytes. The existing Base64 receipt-image workflow is not changed.
- Reminder records are stored in Firestore but are not yet scheduled as Android local notifications.
- Approval records are owner-entered records, not a full submit/review workflow. Existing viewer role remains read-only; configurable viewer permissions are not implemented.
- Dashboard reconciliation, backup/restore, monthly reports, and full offline conflict resolution remain pending.
- No Cloud Functions, Firebase Storage, or Blaze-only services were added.

## Firestore deployment

After reviewing the rules, deploy with:

```bash
npx firebase-tools deploy --only firestore:rules --project ksk-house-construction
```

## Validation

Run in Codespaces:

```bash
npm install
npm run typecheck
git diff --check
npx expo config --type public
```

Then run the Android build workflow and install/test the resulting APK. This archive has no Git metadata, so it cannot itself be committed or pushed.
