import {collection, doc, documentId, getDocs, limit, orderBy, query, runTransaction, serverTimestamp, startAfter, Timestamp} from 'firebase/firestore';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import {db} from '../firebase';
import {ProjectRecordType} from './projectRecords';

const PROJECT_ID='ksk';
const COLLECTIONS:ProjectRecordType[]=['contracts','payments','stock','progress','diary','approvals','reminders'];
const MAX_BACKUP_BYTES=50*1024*1024;
type BackupDoc={id:string;data:Record<string,any>};
type Backup={format:'ksk-project-backup';schemaVersion:1;projectId:string;createdAt:string;sheets:BackupDoc[];collections:Record<string,BackupDoc[]>;attachments:Record<string,BackupDoc[]>};
function utf8ByteLength(value:string){let bytes=0;for(const character of value){const point=character.codePointAt(0)||0;bytes+=point<=0x7f?1:point<=0x7ff?2:point<=0xffff?3:4;}return bytes;}

async function readCollection(pathParts:string[]):Promise<BackupDoc[]> {
  const ref=collection(db!,pathParts.join('/'));
  const output:BackupDoc[]=[];
  let cursor:any;
  while(true){
    const page=await getDocs(query(ref,...(cursor?[orderBy(documentId()),startAfter(cursor)]:[orderBy(documentId())]),limit(400)));
    output.push(...page.docs.map(item=>({id:item.id,data:item.data()})));
    if(page.size<400)break;
    cursor=page.docs[page.docs.length-1];
  }
  return output;
}

function encode(value:any):any {
  if(value instanceof Timestamp)return {$kskTimestamp:value.toDate().toISOString()};
  if(Array.isArray(value))return value.map(encode);
  if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([key,item])=>[key,encode(item)]));
  return value;
}
function decode(value:any):any {
  if(Array.isArray(value))return value.map(decode);
  if(value&&typeof value==='object'){
    if(typeof value.$kskTimestamp==='string'&&Object.keys(value).length===1)return Timestamp.fromDate(new Date(value.$kskTimestamp));
    return Object.fromEntries(Object.entries(value).map(([key,item])=>[key,decode(item)]));
  }
  return value;
}

export async function exportProjectBackup():Promise<string>{
  if(!db||!FileSystem.cacheDirectory)throw new Error('Firebase or local file storage is unavailable.');
  const projectRoot=['projects',PROJECT_ID];
  const sheets=await readCollection([...projectRoot,'sheets']);
  const collections:Record<string,BackupDoc[]>={};
  for(const name of COLLECTIONS)collections[name]=await readCollection([...projectRoot,name]);
  const recordIds=new Set<string>();
  sheets.forEach(sheet=>(sheet.data.recordIds||[]).forEach((id:string)=>id&&recordIds.add(id)));
  collections.payments.forEach(record=>recordIds.add(record.id));
  collections.diary.forEach(record=>recordIds.add(record.id));
  const attachments:Record<string,BackupDoc[]>={};
  for(const id of recordIds){
    for(const group of ['bills','attachments']){
      const docs=await readCollection([...projectRoot,group,id,'images']);
      if(docs.length)attachments[`${group}/${id}`]=docs;
    }
  }
  const backup:Backup={format:'ksk-project-backup',schemaVersion:1,projectId:PROJECT_ID,createdAt:new Date().toISOString(),sheets,collections,attachments};
  const json=JSON.stringify(encode(backup));
  if(utf8ByteLength(json)>MAX_BACKUP_BYTES)throw new Error('Backup exceeds the 50 MiB safe export limit. Export in a smaller set after reducing attached photos.');
  const uri=`${FileSystem.cacheDirectory}KSK_Project_Backup_${new Date().toISOString().slice(0,10)}.json`;
  await FileSystem.writeAsStringAsync(uri,json,{encoding:FileSystem.EncodingType.UTF8});
  if(!(await Sharing.isAvailableAsync()))throw new Error('File sharing is unavailable on this device.');
  await Sharing.shareAsync(uri,{mimeType:'application/json',dialogTitle:'Export KSK project backup'});
  return uri;
}

export function validateProjectBackup(value:any): asserts value is Backup {
  if(!value||value.format!=='ksk-project-backup'||value.schemaVersion!==1||value.projectId!==PROJECT_ID)throw new Error('This is not a supported KSK project backup.');
  if(!Array.isArray(value.sheets)||!value.collections||typeof value.collections!=='object'||!value.attachments||typeof value.attachments!=='object')throw new Error('Backup sections are missing or invalid.');
  for(const name of COLLECTIONS)if(!Array.isArray(value.collections[name]))throw new Error(`Backup collection ${name} is missing.`);
  const validateDocs=(docs:any[],label:string)=>docs.forEach(item=>{
    if(!item||typeof item.id!=='string'||!item.id||item.id.includes('/')||item.id.length>1500||!item.data||typeof item.data!=='object'||Array.isArray(item.data))throw new Error(`Invalid document in ${label}.`);
    if(item.data.imageBase64!==undefined&&(!/^[A-Za-z0-9+/]*={0,2}$/.test(item.data.imageBase64)||item.data.imageBase64.length>450000))throw new Error('Backup contains an invalid or oversized image.');
  });
  validateDocs(value.sheets,'sheets');
  for(const name of COLLECTIONS)validateDocs(value.collections[name],name);
  for(const [key,docs] of Object.entries(value.attachments)){if(!/^(bills|attachments)\/[A-Za-z0-9_-]+$/.test(key)||!Array.isArray(docs))throw new Error('Invalid attachment path in backup.');validateDocs(docs,`attachments/${key}`);}
}

export async function importProjectBackup(json:string,uid:string):Promise<{added:number;skipped:number}>{
  if(!db)throw new Error('Firebase is not configured.');
  if(!uid)throw new Error('Sign in as the project owner to restore a backup.');
  if(utf8ByteLength(json)>MAX_BACKUP_BYTES)throw new Error('Backup exceeds the 50 MiB safe import limit.');
  let backup:any;
  try{backup=JSON.parse(json);}catch{throw new Error('Backup file is not valid JSON.');}
  validateProjectBackup(backup);
  const tasks:{path:string[];id:string;data:Record<string,any>}[]=[];
  backup.sheets.forEach((item:BackupDoc)=>tasks.push({path:['projects',PROJECT_ID,'sheets'],...item}));
  for(const name of COLLECTIONS)backup.collections[name].forEach((item:BackupDoc)=>tasks.push({path:['projects',PROJECT_ID,name],...item}));
  for(const [key,docs] of Object.entries(backup.attachments) as [string,BackupDoc[]][]){const [group,parentId]=key.split('/');docs.forEach(item=>tasks.push({path:['projects',PROJECT_ID,group,parentId,'images'],...item}));}
  let added=0,skipped=0;
  for(let i=0;i<tasks.length;i+=20){
    const chunk=tasks.slice(i,i+20);
    const results=await Promise.all(chunk.map(async task=>runTransaction(db!,async transaction=>{
      const ref=doc(db!,[...task.path,task.id].join('/'));
      const existing=await transaction.get(ref);
      if(existing.exists())return false;
      const imported=decode(task.data);
      const isImage=task.path[task.path.length-1]==='images';
      if(isImage){if(imported.createdAt&&!imported.restoredCreatedAt)imported.restoredCreatedAt=imported.createdAt;imported.createdAt=serverTimestamp();}
      else if(task.path[task.path.length-1]==='sheets'){if(imported.updatedBy&&imported.updatedBy!==uid)imported.restoredUpdatedBy=imported.updatedBy;imported.updatedBy=uid;}
      else {if(imported.createdBy&&imported.createdBy!==uid)imported.restoredCreatedBy=imported.createdBy;if(imported.createdAt&&!imported.restoredCreatedAt)imported.restoredCreatedAt=imported.createdAt;imported.createdBy=uid;imported.createdAt=serverTimestamp();imported.restoredFromBackupAt=new Date().toISOString();imported.backupSchemaVersion=1;}
      transaction.set(ref,imported);
      return true;
    })));
    added+=results.filter(Boolean).length;skipped+=results.length-results.filter(Boolean).length;
  }
  return {added,skipped};
}
