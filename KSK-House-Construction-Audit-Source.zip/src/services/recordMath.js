function summarizeInventory(records = []) {
  const items = new Map();
  for (const row of records) {
    const material = String(row.material || 'Unspecified').trim();
    const unit = String(row.unit || 'units').trim();
    const key = `${material.toLocaleLowerCase()}|${unit.toLocaleLowerCase()}`;
    const stock = items.get(key) || {
      material, unit, purchased: 0, received: 0, returnedToStock: 0,
      returnedToSupplier: 0, used: 0, wastage: 0, lowStockLevel: 0,
      supplier: '', rate: 0
    };
    const quantity = Number(row.quantity) || 0;
    switch (String(row.direction || '').trim().toLowerCase()) {
      case 'purchase': case 'purchased': stock.purchased += quantity; break;
      case 'received': case 'receipt': stock.received += quantity; break;
      case 'returned-to-stock': stock.returnedToStock += quantity; break;
      case 'returned-to-supplier': stock.returnedToSupplier += quantity; break;
      case 'used': stock.used += quantity; break;
      case 'wastage': stock.wastage += quantity; break;
      // Old "returned" rows are deliberately excluded because destination is unknown.
    }
    const threshold = Number(row.lowStockLevel) || 0;
    if (!stock.lowStockLevel && threshold) stock.lowStockLevel = threshold;
    if (!stock.rate && Number(row.unitRate)) stock.rate = Number(row.unitRate);
    if (!stock.supplier && row.supplier) stock.supplier = String(row.supplier);
    items.set(key, stock);
  }
  return [...items.values()].map(item => ({
    ...item,
    available: item.received + item.returnedToStock - item.returnedToSupplier - item.used - item.wastage,
    lowStock: item.lowStockLevel > 0 && item.received + item.returnedToStock - item.returnedToSupplier - item.used - item.wastage <= item.lowStockLevel
  }));
}

function summarizeContracts(contracts = [], payments = []) {
  return contracts.map(contract => {
    const history = payments.filter(payment => payment.contractId === contract.id);
    const advances = history.filter(payment => payment.paymentKind === 'advance').reduce((sum, payment) => sum + (Number(payment.amount) || 0), 0);
    const paid = history.filter(payment => payment.paymentKind !== 'advance').reduce((sum, payment) => sum + (Number(payment.amount) || 0), 0);
    const agreed = Number(contract.agreedAmount) || 0;
    const balance=Math.max(0,agreed-advances-paid);
    const overpaid=Math.max(0,advances+paid-agreed);
    return {contract, history, advances, paid, agreed, balance, overpaid};
  });
}

module.exports = {summarizeInventory, summarizeContracts};
